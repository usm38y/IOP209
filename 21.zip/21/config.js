window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Google drive ",
   "homepage": "http://www.google.com/drive",
   "enableLogoutBttn": false,
   "kioskEnabled": true
};